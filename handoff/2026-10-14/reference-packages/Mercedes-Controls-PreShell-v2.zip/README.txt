MERCEDES DIAGNOSTIC WORKSTATION - CONTROLS REFINEMENT v2.0
===========================================================

Purpose
- Replace icon+percentage dock battery display with just "87%" style text.
  If Windows reports no battery, the dock shows "--" (not a fabricated percentage).
- Replace the old small PIN box with a Mercedes-styled centered touchscreen keypad.
  Mouse, touch, number keys, Backspace, Delete, Enter and Escape are supported.
  PIN stays the same; existing PBKDF2 hash and access/recovery functionality remain.
- Does NOT replace your launcher, logos, dock positioning, Wi-Fi controls, or shell.
- Does NOT change any Windows registry settings or activate custom shell mode.

Prerequisite
- Mercedes Controls pre-shell v1 already installed.
- Logged into Mercedes Windows account; workstation directory is
  %LOCALAPPDATA%\DiagnosticWorkstation

Install (PowerShell; exact ZIP filename in Downloads):
  $zip="$env:USERPROFILE\Downloads\Mercedes-Controls-PreShell-v2.zip"
  $dir="$env:TEMP\Mercedes-Controls-PreShell-v2"
  Expand-Archive -LiteralPath $zip -DestinationPath $dir -Force
  powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "$dir\Install-Mercedes-Controls-v2.ps1"

Restart the running UI (after PASS):
  powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "$env:LOCALAPPDATA\DiagnosticWorkstation\Restart-Mercedes-Controls.ps1"

Test
- Dock battery appears as a readable percentage ONLY.
- SYSTEM > Windows Desktop (PIN): modern keypad, wrong PIN rejected,
  correct existing PIN starts the Windows desktop.
- Return shortcut restores workstation UI.
- Wi-Fi, Settings and Emergency Recovery still work.

After final acceptance of the complete Mercedes installation
- To freeze THIS exact installed set of Mercedes source files:
  & "$env:LOCALAPPDATA\DiagnosticWorkstation\Save-Approved-Mercedes.ps1" -ConfirmApproved
- Output: Documents\DiagnosticWorkstation-ApprovedBuilds\Mercedes-Approved-<timestamp>.zip
- Contains a checksum manifest for future master-installer integration.
- Does NOT include hashed PIN, any individual application setup, network secrets or logs.
- It is a snapshot, NOT a runnable standalone installer. The current master tool
  must be updated later to consume it. Each brand gets its own approved snapshot.

Recovery
- Prior scripts are backed up in a dated ControlBackup-v2-* folder.
- If Windows shell is ever enabled and fails: Ctrl+Shift+Esc > Task Manager
  > Run new task >
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Mercedes\AppData\Local\DiagnosticWorkstation\Restore-ExplorerShell.ps1"

Security
- The PIN is a convenience gate for Desktop mode, NOT a Windows security boundary.
  Anyone with Task Manager/PowerShell access can use the recovery action.
- Always use a real Windows sign-in password for meaningful access control.
