# Restore most recent v2 backup of installed Mercedes dock and controls.
# Does not change custom shell, logo, Launcher.ps1, or PIN file.
& {
    $ErrorActionPreference='Stop'
    $root=Join-Path $env:LOCALAPPDATA 'DiagnosticWorkstation'
    $backups=@(Get-ChildItem -LiteralPath $root -Directory -Filter 'ControlBackup-v2-*' |
        Sort-Object LastWriteTime -Descending)
    if($backups.Count -eq 0){throw 'No Mercedes controls v2 backup found.'}
    $folder=$backups[0].FullName
    foreach($file in @('Dock.ps1','WorkstationControls.ps1')){
        $path=Join-Path $folder $file
        if(-not(Test-Path -LiteralPath $path)){throw "Incomplete backup: $path. Nothing changed."}
        $tokens=$null;$problems=$null
        [void][System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$problems)
        if(@($problems).Count -gt 0){throw "Backup source has syntax errors: $file. Nothing changed."}
    }
    foreach($file in @('Dock.ps1','WorkstationControls.ps1')){
        Copy-Item (Join-Path $folder $file) (Join-Path $root $file) -Force -ErrorAction Stop
    }
    $approved=Join-Path $root 'Save-Approved-Mercedes.ps1'
    $saved=Join-Path $folder 'Save-Approved-Mercedes.ps1'
    if(Test-Path $saved){Copy-Item $saved $approved -Force}
    elseif(Test-Path $approved){Remove-Item $approved -Force}
    Write-Host 'PASS: Mercedes controls restored from v2 backup.' -ForegroundColor Green
    Write-Host "Backup: $folder"
    Write-Host 'Restart Home and Dock using Restart-Mercedes-Controls.ps1.'
}
