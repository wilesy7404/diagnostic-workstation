# Mercedes Diagnostic Workstation - Controls & PIN UI v2.0
# In-place update for Mercedes Controls v1. Does not alter Windows shell.
& {
    $ErrorActionPreference = 'Stop'
    $root = Join-Path $env:LOCALAPPDATA 'DiagnosticWorkstation'
    $dockFile = Join-Path $root 'Dock.ps1'
    $controlFile = Join-Path $root 'WorkstationControls.ps1'
    $profileFile = Join-Path $root 'profile.json'
    $pinFile = Join-Path $root 'controls-pin.json'

    foreach ($path in @($dockFile,$controlFile,$profileFile,$pinFile)) {
        if (-not (Test-Path -LiteralPath $path)) { throw "Required file missing: $path. Nothing changed." }
    }
    $profile = Get-Content -LiteralPath $profileFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if (([string]$profile.displayName) -notmatch 'Mercedes') {
        throw 'This patch applies only to the Mercedes profile. Nothing changed.'
    }

    $dock = [IO.File]::ReadAllText($dockFile)
    $controls = [IO.File]::ReadAllText($controlFile)
    if (-not $dock.Contains('WcBatteryPercent') -or -not $controls.Contains('function Test-ControlPin')) {
        throw 'Mercedes Controls v1 is not installed. Nothing changed.'
    }
    if ($controls.Contains('MERCEDES-CONTROLS-v2-PIN')) {
        throw 'Mercedes Controls v2 is already installed. Nothing changed.'
    }

    # Safely replace the ONE dock battery button. Retain existing button click handler.
    $buttonPattern = '(?s)<Button x:Name="WcBatteryButton"\s[^>]*>.*?</Button>'
    $buttons = [regex]::Matches($dock, $buttonPattern)
    if ($buttons.Count -ne 1) { throw "Expected one dock battery control, found $($buttons.Count). Nothing changed." }
    $newButton = @'
<Button x:Name="WcBatteryButton" Style="{StaticResource DockButton}" ToolTip="Battery percentage">
     <TextBlock x:Name="WcBatteryPercent" Text="--" FontFamily="Segoe UI" FontSize="11" FontWeight="SemiBold" Foreground="#F2F6FC" TextAlignment="Center" HorizontalAlignment="Center" VerticalAlignment="Center" SnapsToDevicePixels="True" />
    </Button>
'@
    $match = $buttons[0]
    $dockFixed = $dock.Substring(0,$match.Index) + $newButton + $dock.Substring($match.Index+$match.Length)

    # No battery icon, no text such as AC. Use -- if there is no readable percentage.
    $oldTick = "} else { `$script:wcBatteryPercent.Text='AC' }"
    $newTick = "} else { `$script:wcBatteryPercent.Text='--' }"
    if (-not $dockFixed.Contains($oldTick)) { throw 'Battery status timer differs from v1; no changes saved.' }
    $dockFixed = $dockFixed.Replace($oldTick,$newTick)
    $oldLoad = "`$script:wcBatteryPercent.Text=if(`$pct -ge 0 -and `$pct -le 1){('{0}%' -f [Math]::Round(`$pct*100))}else{'AC'}"
    $newLoad = "`$script:wcBatteryPercent.Text=if((`$info.BatteryChargeStatus -band [System.Windows.Forms.BatteryChargeStatus]::NoSystemBattery) -eq 0 -and `$pct -ge 0 -and `$pct -le 1){('{0}%' -f [Math]::Round(`$pct*100))}else{'--'}"
    if (-not $dockFixed.Contains($oldLoad)) { throw 'Battery startup code differs from v1; no changes saved.' }
    $dockFixed = $dockFixed.Replace($oldLoad,$newLoad)

    # Replace ONLY Ask-ControlPin; all hashing, PIN data, Wi-Fi, system menus,
    # return/recovery and desktop access functionality remain unchanged.
    $startTag = 'function Ask-ControlPin {'
    $endTag = 'function Ensure-NativeWindows {'
    $start = $controls.IndexOf($startTag,[StringComparison]::Ordinal)
    $end = $controls.IndexOf($endTag,[StringComparison]::Ordinal)
    if ($start -lt 0 -or $end -le $start -or
        $controls.IndexOf($startTag,$start+1,[StringComparison]::Ordinal) -ge 0 -or
        $controls.IndexOf($endTag,$end+1,[StringComparison]::Ordinal) -ge 0) {
        throw 'PIN screen function boundaries differ from expected v1. Nothing changed.'
    }
    $replacement = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'Premium-Pin-Function.ps1frag'))
    $controlsFixed = $controls.Substring(0,$start) + $replacement + "`r`n" + $controls.Substring($end)

    function Assert-PowerShell([string]$source,[string]$name) {
        $tokens=$null; $problems=$null
        [void][System.Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$problems)
        if (@($problems).Count -gt 0) {
            $problems | Select-Object -First 5 -ExpandProperty Message | ForEach-Object {Write-Host $_ -ForegroundColor Red}
            throw "$name PowerShell syntax validation failed. Nothing changed."
        }
    }
    Assert-PowerShell $dockFixed 'Dock'
    Assert-PowerShell $controlsFixed 'PIN controls'
    foreach($helper in @('Save-Approved-Mercedes.ps1')) {
        $path=Join-Path $PSScriptRoot $helper
        if(-not(Test-Path $path)){throw "Package file missing: $helper"}
        Assert-PowerShell ([IO.File]::ReadAllText($path)) $helper
    }

    # Validate the exact modified WPF XAML before writing installed scripts.
    foreach ($item in @(
        @{ Name='Dock'; Text=$dockFixed; Pattern='(?s)\$xml\s*=\s*@''\s*\r?\n(.*?)\r?\n''@' },
        @{ Name='PIN'; Text=$controlsFixed; Pattern='(?s)function Ask-ControlPin\s*\{.*?\$xaml\s*=\s*@''\s*\r?\n(.*?)\r?\n''@' }
    )) {
        $m=[regex]::Match($item.Text,$item.Pattern)
        if(-not $m.Success){throw "Cannot locate $($item.Name) XAML. Nothing changed."}
        try { [void][xml]$m.Groups[1].Value }
        catch { throw "$($item.Name) XAML validation failed. Nothing changed. $_" }
    }

    # Back up all files before a write; restore on any partial failure.
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    $backupDir=Join-Path $root ('ControlBackup-v2-'+$stamp)
    New-Item -ItemType Directory -Path $backupDir -ErrorAction Stop | Out-Null
    $saveApprovedPath=Join-Path $root 'Save-Approved-Mercedes.ps1'
    foreach($file in @($dockFile,$controlFile,$saveApprovedPath)) {
        if(Test-Path -LiteralPath $file) { Copy-Item -LiteralPath $file -Destination (Join-Path $backupDir ([IO.Path]::GetFileName($file))) -ErrorAction Stop }
    }
    $hadSaveApproved = Test-Path -LiteralPath $saveApprovedPath
    try {
        $enc=New-Object System.Text.UTF8Encoding($false)
        [IO.File]::WriteAllText($controlFile,$controlsFixed,$enc)
        [IO.File]::WriteAllText($dockFile,$dockFixed,$enc)
        Copy-Item (Join-Path $PSScriptRoot 'Save-Approved-Mercedes.ps1') $saveApprovedPath -Force -ErrorAction Stop
    } catch {
        Copy-Item (Join-Path $backupDir 'WorkstationControls.ps1') $controlFile -Force -ErrorAction SilentlyContinue
        Copy-Item (Join-Path $backupDir 'Dock.ps1') $dockFile -Force -ErrorAction SilentlyContinue
        if($hadSaveApproved) {Copy-Item (Join-Path $backupDir 'Save-Approved-Mercedes.ps1') $saveApprovedPath -Force -ErrorAction SilentlyContinue}
        else {Remove-Item $saveApprovedPath -Force -ErrorAction SilentlyContinue}
        throw
    }

    Write-Host "`nPASS: Mercedes Controls v2 installed." -ForegroundColor Green
    Write-Host 'Dock now displays battery percentage only.'
    Write-Host 'Touch-friendly Mercedes PIN screen installed; existing PIN preserved.'
    Write-Host "Backup folder: $backupDir"
    Write-Host 'Windows Explorer shell setting was NOT changed.'
    Write-Host 'Use Restart-Mercedes-Controls.ps1 from the existing install to reload.'
    Write-Host 'After testing and approving the Mercedes build, run Save-Approved-Mercedes.ps1 -ConfirmApproved.'
}
