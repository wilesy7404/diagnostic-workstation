Diagnostic Workstation Manager 0.1.2-beta.1

Fixes: local brand identity graphics for all nine profiles, manufacturer-specific accent palettes, bottom-docked UI matching the BMW positioning baseline, shared universal update feed.

The VW/Audi, Toyota and Honda badges in this beta are custom text wordmarks rather than official trademark artwork. Other brand assets are design-stage emblem references; check accuracy and licensing before distribution.

Run EXE from the desired manufacturer Windows installation. Brand selection and Programs & Features uninstall remain available. Existing apps.json is preserved on reinstall.

SAFETY: Windows Explorer is deliberately retained as the default shell for first tests. BMW legacy installation is not modified. The GUI executable has been cross-compiled and embedded files structurally checked, but Windows runtime installer/launch tests are still needed.
