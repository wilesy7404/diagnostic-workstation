BMW STEALTH LAUNCHER - CONTROLS v1 (for the Windows account Pro)

This is NOT a Mercedes update. It targets the existing BMW installation at:
  %LOCALAPPDATA%\BMW-Stealth-Launcher

Adds to BMW's SYSTEM popup and dock:
  - Battery percentage ONLY, no battery icon. If no battery, displays --.
  - Wi-Fi network scan/connect (netsh; WPA2-Personal and saved networks; Settings fallback)
  - Windows Settings entry
  - Touch-friendly BMW-styled 6-12 digit PIN for desktop access
  - Emergency Explorer recovery
  - Return to BMW Workstation shortcut on desktop

Important safety:
  - NO change to the current Windows shell, Watchdog.ps1, updater, launcher graphics,
    dock hide/reveal logic, or BMW apps.json.
  - Installer checks the current BMW layout before any changes. Refuses unfamiliar
    BMW script versions instead of overwriting working files.
  - Existing BMW Windows account does not use the Mercedes profile.json layout.
  - PIN only controls the menu action, not Windows authentication. Task Manager,
    administrator accounts, and emergency recovery remain accessible.
  - Wi-Fi password for new WPA2 networks is handled temporarily by netsh XML; other
    security modes should use Windows Settings. Test on the machine.
  - If a future BMW update replaces Dock.ps1 or SystemPanel.ps1, controls will
    need to be re-applied after comparing the updated source.

Install (PowerShell, sign in to BMW/Pro):
  $zip="$env:USERPROFILE\Downloads\BMW-Stealth-Controls-v1.zip"
  $dir="$env:TEMP\BMW-Stealth-Controls-v1"
  Expand-Archive -LiteralPath $zip -DestinationPath $dir -Force
  powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "$dir\Install-BMW-Controls-v1.ps1" -VerifyOnly
  powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "$dir\Install-BMW-Controls-v1.ps1"

After PASS:
  powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "$env:LOCALAPPDATA\BMW-Stealth-Launcher\Restart-BMW-Controls.ps1"

Rollback (if needed):
  powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "$env:LOCALAPPDATA\BMW-Stealth-Launcher\Rollback-BMW-Controls-v1.ps1"

Emergency Explorer recovery from Task Manager > Run new task:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Pro\AppData\Local\BMW-Stealth-Launcher\Restore-BMW-ExplorerShell.ps1"

Save APPROVED BMW source when fully tested:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$env:LOCALAPPDATA\BMW-Stealth-Launcher\Save-Approved-BMW.ps1" -ConfirmApproved

Do not assume successful Windows runtime behavior until you have tested in BMW.
