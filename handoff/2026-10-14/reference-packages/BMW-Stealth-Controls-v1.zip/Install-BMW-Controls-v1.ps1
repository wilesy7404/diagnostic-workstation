﻿# BMW Stealth Launcher - Controls v1.0
# Target: CURRENT USER's %LOCALAPPDATA%\BMW-Stealth-Launcher.
# This script never changes Shell registry, Watchdog, Launcher, UpdateAgent, or apps.json.
param([switch]$VerifyOnly)
& {
    $ErrorActionPreference='Stop'
    $root=Join-Path $env:LOCALAPPDATA 'BMW-Stealth-Launcher'
    $dockFile=Join-Path $root 'Dock.ps1'
    $panelFile=Join-Path $root 'SystemPanel.ps1'
    $launcherFile=Join-Path $root 'Launcher.ps1'
    $pinFile=Join-Path $root 'controls-pin.json'
    $newFiles=@('BMWWorkstationControls.ps1','Restore-BMW-ExplorerShell.ps1','Restart-BMW-Controls.ps1','Rollback-BMW-Controls-v1.ps1','Save-Approved-BMW.ps1')
    foreach($f in @($dockFile,$panelFile,$launcherFile)) {
        if(-not(Test-Path -LiteralPath $f -PathType Leaf)){throw "BMW file missing: $f. Nothing changed."}
    }
    $launcher=[IO.File]::ReadAllText($launcherFile)
    $dock=[IO.File]::ReadAllText($dockFile)
    $panel=[IO.File]::ReadAllText($panelFile)
    if(-not $launcher.Contains('BMW Diagnostic System') -or -not $dock.Contains('BMW Glass Dock')) {
        throw 'Installed workstation is not the expected BMW build. No files changed.'
    }
    if(-not $launcher.Contains('SystemPanel.ps1') -or -not $panel.Contains('New-WorkstationSystemPopup')) {
        throw 'BMW system menu implementation does not match this update. No files changed.'
    }
    if($dock.Contains('BMW-SAFE-CONTROLS-v1') -or $panel.Contains('BMW-SAFE-CONTROLS-v1')){
        throw 'BMW controls are already installed. Nothing changed.'
    }

    function Replace-Once([string]$text,[string]$needle,[string]$replacement,[string]$description) {
        $i=$text.IndexOf($needle,[StringComparison]::Ordinal)
        if($i -lt 0) {throw "Unsupported BMW version: $description not found. Nothing changed."}
        if($text.IndexOf($needle,$i+$needle.Length,[StringComparison]::Ordinal) -ge 0){throw "Duplicate $description detected. Nothing changed."}
        return $text.Substring(0,$i)+$replacement+$text.Substring($i+$needle.Length)
    }

    # BMW popup remains attached and retains its current visual layout.
    $homeButtons=@'
        <Button x:Name="BmwWifi" Content="Wi-Fi &amp; Internet"/>
        <Button x:Name="BmwBattery" Content="Battery Status"/>
        <Button x:Name="BmwDesktop" Content="Windows Desktop (PIN)"/>
        <Button x:Name="BmwRecovery" Content="Emergency Recovery"/>
'@
    $panel=Replace-Once $panel '<Button x:Name="Internet"' ($homeButtons + '        <Button x:Name="Internet"') 'SYSTEM menu buttons'
    $panelActions=@'
        BmwWifi     = { Invoke-BMWControl 'Wifi' }
        BmwBattery  = { Invoke-BMWControl 'Battery' }
        BmwDesktop  = { Invoke-BMWControl 'Desktop' }
        BmwRecovery = { Invoke-BMWControl 'Recovery' }
'@
    $panel=Replace-Once $panel '    $actions = @{' ("    `$actions = @{`r`n"+$panelActions) 'SYSTEM action table'
    $panelFunction=@'
# BMW-SAFE-CONTROLS-v1 - external controls run in their own WPF UI process.
function Invoke-BMWControl([string]$Mode) {
    $path=Join-Path $env:LOCALAPPDATA 'BMW-Stealth-Launcher\BMWWorkstationControls.ps1'
    if(-not(Test-Path -LiteralPath $path)){throw "BMW controls missing: $path"}
    $ps=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Start-Process -FilePath $ps -WindowStyle Hidden -ArgumentList @(
        '-NoProfile','-STA','-ExecutionPolicy','Bypass',"-File `"$path`"",'-Mode',$Mode
    )
}
'@
    $panel=$panelFunction+"`r`n"+$panel

    # Dock: battery is a single 11px percentage, no battery icon; preserve animation and position code.
    $dockBattery=@'
<Button x:Name="BmwBatteryButton" Style="{StaticResource DockButton}" ToolTip="Battery percentage">
    <TextBlock x:Name="BmwBatteryPercent" Text="--" FontSize="11" FontWeight="SemiBold" FontFamily="Segoe UI"
               Foreground="#EDF5FF" TextAlignment="Center" VerticalAlignment="Center"
               HorizontalAlignment="Center" SnapsToDevicePixels="True"/>
   </Button>
   <Button x:Name="System"
'@
    $dock=Replace-Once $dock '<Button x:Name="System"' $dockBattery 'dock battery button'
    $dockHelper=@'
# BMW-SAFE-CONTROLS-v1
function Invoke-BMWDockControl([string]$Mode) {
    $path=Join-Path $env:LOCALAPPDATA 'BMW-Stealth-Launcher\BMWWorkstationControls.ps1'
    if(-not(Test-Path -LiteralPath $path)){throw "BMW controls missing: $path"}
    $ps=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Start-Process -FilePath $ps -WindowStyle Hidden -ArgumentList @(
        '-NoProfile','-STA','-ExecutionPolicy','Bypass',"-File `"$path`"",'-Mode',$Mode
    )
}
$window.FindName('BmwBatteryButton').Add_Click({Invoke-BMWDockControl 'Battery'})
'@
    $dock=Replace-Once $dock '$menu=New-Object System.Windows.Controls.ContextMenu' ($dockHelper+"`r`n"+'$menu=New-Object System.Windows.Controls.ContextMenu') 'dock menu initialization'
    $choices=@'
$choices+=@(
 @{Text='Wi-Fi & Internet';Cmd='bmwwifi'},
 @{Text='Battery Status';Cmd='bmwbattery'},
 @{Text='Windows Settings';Cmd='bmwsettings'},
 @{Text='Windows Desktop (PIN)';Cmd='bmwdesktop'},
 @{Text='Emergency Recovery';Cmd='bmwrecovery'}
)
'@
    $dock=Replace-Once $dock 'foreach($c in $choices){' ($choices+"`r`n"+'foreach($c in $choices){') 'dock menu choices'
    $cases=@'
   bmwwifi {Invoke-BMWDockControl 'Wifi'}
   bmwbattery {Invoke-BMWDockControl 'Battery'}
   bmwsettings {Invoke-BMWDockControl 'Settings'}
   bmwdesktop {Invoke-BMWDockControl 'Desktop'}
   bmwrecovery {Invoke-BMWDockControl 'Recovery'}
'@
    $dock=Replace-Once $dock "   taskmgr {Start-Process 'taskmgr.exe'}" ("   taskmgr {Start-Process 'taskmgr.exe'}`r`n"+$cases) 'dock menu action switch'
    $status=@'
# BMW battery indicator updates without modifying home/fullscreen auto-hide logic.
$script:bmwBatteryPercent=$window.FindName('BmwBatteryPercent')
$bmwBatteryTimer=New-Object System.Windows.Threading.DispatcherTimer
$bmwBatteryTimer.Interval=[TimeSpan]::FromSeconds(20)
$bmwBatteryUpdate={
    try {
        $info=[System.Windows.Forms.SystemInformation]::PowerStatus
        $percent=$info.BatteryLifePercent
        if($percent -ge 0 -and $percent -le 1 -and
           ($info.BatteryChargeStatus -band [System.Windows.Forms.BatteryChargeStatus]::NoSystemBattery) -eq 0) {
            $script:bmwBatteryPercent.Text=('{0}%' -f [Math]::Round($percent*100))
        } else { $script:bmwBatteryPercent.Text='--' }
    } catch { $script:bmwBatteryPercent.Text='--' }
}
$bmwBatteryTimer.Add_Tick($bmwBatteryUpdate)
$window.Add_Loaded({ & $bmwBatteryUpdate; $bmwBatteryTimer.Start() })
'@
    $dock=Replace-Once $dock '[void]$window.ShowDialog()' ($status+"`r`n"+'[void]$window.ShowDialog()') 'dock ShowDialog'

    # Validate all changed scripts, and the two embedded XAML blocks, before writing.
    function Check-Source([string]$src,[string]$caption) {
        $tok=$null; $bad=$null
        [void][System.Management.Automation.Language.Parser]::ParseInput($src,[ref]$tok,[ref]$bad)
        $issues=@($bad | Where-Object { $null -ne $_ })
        if($issues.Count -gt 0) {
            $issues | Select-Object -First 4 -ExpandProperty Message | ForEach-Object {Write-Host $_ -ForegroundColor Red}
            throw "$caption is not valid PowerShell. No changes made."
        }
    }
    Check-Source $panel 'SystemPanel'
    Check-Source $dock 'Dock'
    foreach($file in $newFiles) {
        $src=Join-Path $PSScriptRoot $file
        if(-not(Test-Path -LiteralPath $src)){throw "Update package incomplete: $file"}
        Check-Source ([IO.File]::ReadAllText($src)) $file
    }
    foreach($item in @(
       @{name='SystemPanel';src=$panel;pattern='(?s)\[xml\]\$xaml\s*=\s*@''\s*\r?\n(.*?)\r?\n''@'},
       @{name='Dock';src=$dock;pattern='(?s)\$xml\s*=\s*@''\s*\r?\n(.*?)\r?\n''@'}
    )) {
        $m=[regex]::Match($item.src,$item.pattern)
        if(-not $m.Success){throw "$($item.name) XAML not found. Nothing changed."}
        try {[void][xml]$m.Groups[1].Value}
        catch {throw "$($item.name) XAML invalid. Nothing changed: $_"}
    }

    if($VerifyOnly) {
        Write-Host 'PASS: BMW files compatible; scripts and XAML validated. No changes made.' -ForegroundColor Green
        return
    }

    # Set up PIN only if not already present. Do not ship a default PIN.
    $newPin=$null
    if(-not(Test-Path -LiteralPath $pinFile)) {
        Write-Host 'Create your BMW desktop passcode (6-12 digits).' -ForegroundColor Cyan
        function Read-Pin([string]$prompt) {
            $sec=Read-Host -Prompt $prompt -AsSecureString
            $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
            try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
            finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr);$sec.Dispose()}
        }
        $pin1=Read-Pin 'New BMW PIN'
        $pin2=Read-Pin 'Confirm BMW PIN'
        if($pin1 -cnotmatch '^[0-9]{6,12}$' -or $pin1 -cne $pin2) {
            throw 'PIN must be 6-12 digits and entries must match. Nothing changed.'
        }
        $salt=New-Object byte[] 16
        $rng=[System.Security.Cryptography.RandomNumberGenerator]::Create()
        try {$rng.GetBytes($salt)}finally{$rng.Dispose()}
        $kdf=New-Object System.Security.Cryptography.Rfc2898DeriveBytes($pin1,$salt,150000)
        try {$hashed=$kdf.GetBytes(32)}finally{$kdf.Dispose()}
        $newPin=([pscustomobject]@{version=1;iterations=150000;salt=[Convert]::ToBase64String($salt);hash=[Convert]::ToBase64String($hashed)} | ConvertTo-Json -Compress)
        $pin1=$null;$pin2=$null
    }

    # Backup every replaced file and roll back fully on a write failure.
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    $backupDir=Join-Path $root ('BMW-ControlBackup-v1-'+$stamp)
    New-Item -ItemType Directory -Path $backupDir -ErrorAction Stop | Out-Null
    $targets=@($panelFile,$dockFile,$pinFile)+@($newFiles | ForEach-Object {Join-Path $root $_})
    foreach($target in $targets) {
        if(Test-Path -LiteralPath $target){Copy-Item -LiteralPath $target -Destination (Join-Path $backupDir ([IO.Path]::GetFileName($target))) -ErrorAction Stop}
    }
    $enc=New-Object System.Text.UTF8Encoding($true)
    try {
        foreach($file in $newFiles) {Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $root $file) -ErrorAction Stop}
        if($newPin){[IO.File]::WriteAllText($pinFile,$newPin,$enc)}
        [IO.File]::WriteAllText($panelFile,$panel,$enc)
        [IO.File]::WriteAllText($dockFile,$dock,$enc)
    } catch {
        foreach($target in $targets) {
            $save=Join-Path $backupDir ([IO.Path]::GetFileName($target))
            if(Test-Path $save){Copy-Item $save $target -Force -ErrorAction SilentlyContinue}
            elseif(Test-Path $target){Remove-Item $target -Force -ErrorAction SilentlyContinue}
        }
        throw
    }

    try {
        $desktop=[Environment]::GetFolderPath('DesktopDirectory')
        if(Test-Path -LiteralPath $desktop) {
            $shortcut=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop 'Return to BMW Workstation.lnk'))
            $shortcut.TargetPath=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $controlPath=Join-Path $root 'BMWWorkstationControls.ps1'
            $shortcut.Arguments="-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$controlPath`" -Mode Return"
            $shortcut.WorkingDirectory=$root
            $shortcut.Description='Return to BMW Diagnostic Workstation'
            $shortcut.Save()
        }
    } catch {Write-Warning 'Could not create Return to BMW shortcut. The Return command remains available.'}

    Write-Host "`nPASS: BMW controls v1 installed (existing shell unchanged)." -ForegroundColor Green
    Write-Host "Backup: $backupDir"
    Write-Host 'Test Wi-Fi, Settings, percentage battery, PIN desktop, Return, and Recovery before approval.'
}
