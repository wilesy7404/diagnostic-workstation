# Diagnostic Workstation — Universal Manager (Beta 0.1.0)

A self-contained x64 Windows GUI EXE with a nine-brand selector. Install is per signed-in Windows account; it never modifies machine-wide Winlogon.

## Supported brands
BMW, Mercedes-Benz, Porsche, Volkswagen/Audi, Toyota/Lexus, Ford/Lincoln, Honda/Acura, GM/Chevrolet, Jaguar Land Rover.

## Setup
1. Extract `Diagnostic-Workstation-Master-Setup.zip` and run `Diagnostic-Workstation-Master-Setup.exe` from the *correct brand's Windows installation*.
2. If this Windows account previously used the V2/V3 Mercedes setup, click **REMOVE OLD MERCEDES** first. This backs up any `apps.json` and logs and removes only Mercedes workstation scripts/startup shortcuts; it does NOT uninstall XENTRY, DTS Monaco, Vediamo, or other OEM software.
3. Select your brand. Choose whether to launch at Windows sign-in. Click **INSTALL SELECTED BRAND**.
4. In the installed **ADMIN** menu, set the actual paths to your locally licensed diagnostic applications.
5. To uninstall, open Windows **Settings > Apps > Installed apps > Diagnostic Workstation** (per-user uninstall entry), or use the manager's **UNINSTALL WORKSTATION** button. Settings backups go to `%LOCALAPPDATA%\DiagnosticWorkstation-Backups`.

## Paths
Installed app: `%LOCALAPPDATA%\DiagnosticWorkstation`
Saved app configuration: `apps.json` (preserved on reinstall)
Selected brand: `profile.json`
Release metadata: `version.json`
Updater: `UpdateAgent.ps1`, `UpdateRunner.ps1`, `ApplyUpdate.ps1`
Logs: `logs\Manager.log`, `logs\Launcher.log`, `logs\Dock.log`, `logs\UpdateAgent.log`
HKCU startup value: `UniversalDiagnosticWorkstation`
HKCU uninstall key: `Software\Microsoft\Windows\CurrentVersion\Uninstall\UniversalDiagnosticWorkstation`

## Shared updates (important)
All brands run the SAME launcher and updater code, parametrized by `profile.json`. The update feed filters ONLY GitHub release tags `universal-v<SemVer>`, not `v...`, `mercedes-v...`, `bmw-v...`. This intentionally avoids installing a BMW-only package over another brand. One published universal ZIP applies to every profile and must contain `core/{Launcher,Dock,Watchdog,SystemPanel}.ps1` and `version.json`, plus the GitHub release assets `update-manifest.json` and `workstation.zip.sha256`. Installed app paths and `profile.json` are protected.

**No universal release has been published yet; the initial feed will correctly report `unconfigured` until one is available.** Publishing the first universal update should follow runtime tests on Windows. A release builder is included as `BUILD-UNIVERSAL-RELEASE.ps1`.

## Safety and limitations
- **Beta — Windows runtime not yet tested.** ZIP/file structure and Go cross-compilation are verified here; run one controlled Windows installation/uninstall before deploying to other partitions.
- First-run installs keep **Explorer as the Windows shell**; shell takeover is intentionally withheld because a prior experimental installer failed to verify the WPF window and removed files during rollback. This initial master release does *not* reproduce BMW's machine-wide custom Winlogon takeover. We can add an opt-in supervised shell switch after this installer is proven.
- The manager uses a native Windows GUI; application UI uses WPF on Windows PowerShell 5.1. No password/login or OEM assets included.
- Installer EXE unsigned: a Windows SmartScreen warning is possible. Never bypass a warning if you cannot verify the file source.
- The updater's download SHA-256 protects against inadvertent corruption, not compromise of GitHub release permissions. For production, code signing and signed manifests are advisable.
- Uninstall preserves `apps.json` and selected profile in a separate backup by default. Never blindly remove another brand's partition or unrelated files.
