param([Parameter(Mandatory=$true)][string]$Version)
$ErrorActionPreference='Stop'
if($Version -notmatch '^\d+\.\d+\.\d+(?:-beta\.\d+)?$'){throw 'Use SemVer such as 0.1.1-beta.1'}
$src=Join-Path $PSScriptRoot 'assets'
$dist=Join-Path $PSScriptRoot 'release-dist'
$pkg=Join-Path $dist 'package'
if(Test-Path $dist){Remove-Item $dist -Recurse -Force}
New-Item -ItemType Directory -Force (Join-Path $pkg 'core')|Out-Null
foreach($n in @('Launcher.ps1','Dock.ps1','Watchdog.ps1','SystemPanel.ps1')){
 $p=Join-Path $src $n
 $t=$null;$e=$null
 [void][Management.Automation.Language.Parser]::ParseFile($p,[ref]$t,[ref]$e)
 if(@($e).Count){throw "Syntax error in $n : $($e[0].Message)"}
 Copy-Item $p (Join-Path (Join-Path $pkg 'core') $n)
}
@{version=$Version}|ConvertTo-Json -Compress|Set-Content (Join-Path $pkg 'version.json') -Encoding UTF8
Compress-Archive -Path (Join-Path $pkg '*') -DestinationPath (Join-Path $dist 'workstation.zip') -CompressionLevel Optimal
$sha=(Get-FileHash (Join-Path $dist 'workstation.zip') -Algorithm SHA256).Hash.ToLowerInvariant()
@{schemaVersion=1;version=$Version;channel='beta';asset='workstation.zip';sha256=$sha}|ConvertTo-Json -Compress|Set-Content (Join-Path $dist 'update-manifest.json') -Encoding UTF8
"$sha  workstation.zip"|Set-Content (Join-Path $dist 'workstation.zip.sha256')
Write-Host "Ready: $dist" -ForegroundColor Green
Write-Host "Release tag: universal-v$Version"
Write-Host 'Upload exactly: workstation.zip, workstation.zip.sha256, update-manifest.json'
Write-Host 'This is a shared universal release. Do NOT use a BMW-specific or Mercedes-specific tag.'
