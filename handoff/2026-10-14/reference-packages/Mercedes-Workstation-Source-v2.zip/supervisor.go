// Mercedes Workstation Supervisor v2 — signed-in-user GUI process.
// Creates no PowerShell console, but DOES NOT set SW_HIDE on the WPF windows.
package main

import (
 "fmt"
 "os"
 "os/exec"
 "path/filepath"
 "runtime"
 "syscall"
 "time"
 "unsafe"
)

const createNoWindow = 0x08000000

func writeLog(f string, s string) {
 _ = os.MkdirAll(filepath.Dir(f), 0700)
 out, err := os.OpenFile(f, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0600)
 if err == nil {fmt.Fprintf(out, "%s %s\r\n", time.Now().Format("2006-01-02T15:04:05"), s);out.Close()}
}
func singleInstance() bool {
 k := syscall.NewLazyDLL("kernel32.dll")
 fn := k.NewProc("CreateMutexW")
 name, _ := syscall.UTF16PtrFromString("Local\\MercedesDiagnosticWorkstationSupervisorV2")
 h, _, last := fn.Call(0, 1, uintptr(unsafe.Pointer(name)))
 runtime.KeepAlive(name)
 if h == 0 {return false}
 if errno,ok:=last.(syscall.Errno);ok && errno == 183 {return false}
 return true
}
func supervise(root, name, script string) {
 logDir := filepath.Join(root,"logs")
 exe := filepath.Join(os.Getenv("WINDIR"),"System32","WindowsPowerShell","v1.0","powershell.exe")
 path := filepath.Join(root,script)
 for {
  if _,err:=os.Stat(path);err!=nil {
   writeLog(filepath.Join(logDir,"Supervisor.log"),"MISSING "+script+": "+err.Error())
   time.Sleep(10*time.Second)
   continue
  }
  outPath:=filepath.Join(logDir,name+".log")
  _=os.MkdirAll(logDir,0700)
  out,err:=os.OpenFile(outPath,os.O_APPEND|os.O_CREATE|os.O_WRONLY,0600)
  if err!=nil {time.Sleep(5*time.Second); continue}
  cmd:=exec.Command(exe,"-NoProfile","-STA","-ExecutionPolicy","Bypass","-File",path)
  cmd.Dir=root
  cmd.SysProcAttr=&syscall.SysProcAttr{CreationFlags:createNoWindow}
  cmd.Stdout=out
  cmd.Stderr=out
  startTime:=time.Now()
  err=cmd.Start()
  if err==nil {
   writeLog(filepath.Join(logDir,"Supervisor.log"),fmt.Sprintf("START %s PID=%d",name,cmd.Process.Pid))
   err=cmd.Wait()
  }
  writeLog(filepath.Join(logDir,"Supervisor.log"),fmt.Sprintf("EXIT %s elapsed=%s error=%v",name,time.Since(startTime).Round(time.Second),err))
  out.Close()
  // Backoff so a repeatedly crashing WPF component cannot spin hundreds of times.
  time.Sleep(6*time.Second)
 }
}
func main(){
 if !singleInstance(){return}
 root:=filepath.Join(os.Getenv("LOCALAPPDATA"),"Mercedes-Diagnostic-Workstation")
 log:=filepath.Join(root,"logs","Supervisor.log")
 writeLog(log,"Mercedes GUI supervisor started (console-free child processes)")
 go supervise(root,"Dock","Dock.ps1")
 go supervise(root,"UpdateAgent","UpdateAgent.ps1")
 supervise(root,"Launcher","Launcher.ps1")
}
