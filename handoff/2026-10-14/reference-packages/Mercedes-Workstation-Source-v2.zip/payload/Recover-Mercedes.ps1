$ErrorActionPreference='Stop'
$r=Join-Path $env:LOCALAPPDATA 'Mercedes-Diagnostic-Workstation'
$backup=Get-ChildItem -LiteralPath $r -Directory -Filter 'Backup-Installer-*' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if(-not $backup){Write-Host 'No installer backup found.';exit 1}
foreach($n in @('Launcher.ps1','Dock.ps1','Watchdog.ps1','SystemPanel.ps1','apps.json','version.json')){
 $old=Join-Path $backup.FullName $n
 if(Test-Path -LiteralPath $old){Copy-Item -LiteralPath $old -Destination (Join-Path $r $n) -Force}
}
Start-Process 'explorer.exe'
Write-Host 'Previous files restored. Sign out and back in if the launcher is already running.' -ForegroundColor Green
