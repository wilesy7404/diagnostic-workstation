param([Parameter(Mandatory=$true)][string]$PayloadDirectory)
$ErrorActionPreference='Stop'
$root=Join-Path $env:LOCALAPPDATA 'Mercedes-Diagnostic-Workstation'
$log=Join-Path $env:TEMP 'Mercedes-Workstation-Install.log'
function Log([string]$msg){Add-Content -LiteralPath $log -Value (('{0}  {1}' -f (Get-Date -Format 's'),$msg))}
$files=@('Launcher.ps1','Dock.ps1','Watchdog.ps1','SystemPanel.ps1','UpdateAgent.ps1','UpdateRunner.ps1','ApplyUpdate.ps1','MercedesSupervisor.exe','SilentStart.vbs','version.json','update-settings.json','update-status.json')
$previous=@{}
$runKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$runName='MercedesDiagnosticWorkstation'
$oldRun=(Get-ItemProperty -Path $runKey -Name $runName -ErrorAction SilentlyContinue).$runName
$backup=$null
$created=@()
try {
 Log 'Starting installation'
 if(-not (Test-Path -LiteralPath $PayloadDirectory -PathType Container)){throw 'Installer payload missing'}
 if(-not(Test-Path -LiteralPath (Join-Path $PayloadDirectory 'MercedesSupervisor.exe'))){throw 'Mercedes supervisor missing from installer payload'}
 foreach($name in @('Launcher.ps1','Dock.ps1','Watchdog.ps1','SystemPanel.ps1','UpdateAgent.ps1','UpdateRunner.ps1','ApplyUpdate.ps1')){
  $p=Join-Path $PayloadDirectory $name
  if(-not(Test-Path -LiteralPath $p)){throw "Installer source missing $name"}
  $t=$null;$parseErrors=$null
  [void][Management.Automation.Language.Parser]::ParseFile($p,[ref]$t,[ref]$parseErrors)
  if(@($parseErrors).Count -gt 0){throw "PowerShell syntax failed: $name -- $($parseErrors[0].Message)"}
 }
 $conflicting=@(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object {$_.CommandLine -match 'BMW-Stealth-Launcher\\(Launcher|Watchdog)\.ps1'})
 if($conflicting.Count -gt 0){throw 'BMW workstation is active in this Windows session. Install Mercedes into its separate Windows installation, not over the running BMW desktop.'}
 # Also protect Windows installations using BMW as a registered Winlogon shell,
 # even when the BMW launcher isn't running at the instant of installation.
 foreach($key in @('HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon','HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon')){
  $activeShell=[string](Get-ItemProperty -Path $key -Name Shell -ErrorAction SilentlyContinue).Shell
  if($activeShell -match 'BMW-Stealth-Launcher'){
   throw 'This Windows installation has BMW configured as its login shell. Boot into the separate Mercedes Windows installation first.'
  }
 }
 $inProgress=@(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object {$_.CommandLine -match 'Mercedes-Diagnostic-Workstation\\(UpdateRunner|ApplyUpdate)\.ps1'})
 if($inProgress.Count -gt 0){throw 'Mercedes update in progress. Try again after it finishes.'}
 [void](New-Item -Path $root -ItemType Directory -Force)
 $backup=Join-Path $root ('Backup-Installer-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
 [void](New-Item -Path $backup -ItemType Directory -Force)
 foreach($name in $files){
  $old=Join-Path $root $name
  $previous[$name]=(Test-Path -LiteralPath $old -PathType Leaf)
  if($previous[$name]){Copy-Item -LiteralPath $old -Destination (Join-Path $backup $name) -Force}
 }
 if(Test-Path -LiteralPath (Join-Path $root 'apps.json')){
  Copy-Item (Join-Path $root 'apps.json') (Join-Path $backup 'apps.json') -Force
 }
 # Stop only older Mercedes background processes so this reinstall can replace files safely.
 # Start the new GUI-mode supervisor without -WindowStyle Hidden: only its console children
 # are suppressed; separately-created WPF windows remain visible on the signed-in desktop.
 $stale=@(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
  ($_.Name -ieq 'MercedesSupervisor.exe' -and $_.ExecutablePath -eq (Join-Path $root 'MercedesSupervisor.exe')) -or
  ($_.Name -ieq 'powershell.exe' -and $_.CommandLine -match 'Mercedes-Diagnostic-Workstation\\(Launcher|Watchdog|Dock|UpdateAgent)\.ps1')
 })
 foreach($item in $stale){Stop-Process -Id $item.ProcessId -Force -ErrorAction SilentlyContinue}
 Start-Sleep -Seconds 2


 foreach($name in $files){
  if($name -in @('version.json','update-settings.json','update-status.json') -and $previous[$name]){continue} # preserve existing install version and channel settings
  Copy-Item -LiteralPath (Join-Path $PayloadDirectory $name) -Destination (Join-Path $root $name) -Force
  $created+= $name
 }
 if(-not(Test-Path -LiteralPath (Join-Path $root 'apps.json'))){
  Copy-Item -LiteralPath (Join-Path $PayloadDirectory 'apps-template.json') -Destination (Join-Path $root 'apps.json')
  $created+= 'apps.json'
 }
 # User-local logon startup; Explorer is deliberately kept as the Windows shell.
 New-Item -Path $runKey -Force | Out-Null
 $runCmd='"'+(Join-Path $root 'MercedesSupervisor.exe')+'"'
 New-ItemProperty -Path $runKey -Name $runName -PropertyType String -Value $runCmd -Force | Out-Null

 # Replace our own existing desktop shortcut; no other desktop icons are touched.
 $desktop=[Environment]::GetFolderPath('Desktop')
 if($desktop -and (Test-Path $desktop)){
  $shortcutPath=Join-Path $desktop 'Mercedes Diagnostic Workstation.lnk'
  $shortcut=(New-Object -ComObject WScript.Shell).CreateShortcut($shortcutPath)
  $shortcut.TargetPath=Join-Path $root 'MercedesSupervisor.exe'
  $shortcut.Arguments=''
  $shortcut.WorkingDirectory=$root
  $shortcut.Description='Open the Mercedes Diagnostic Workstation'
  $shortcut.Save()
 }

 $supervisor=Join-Path $root 'MercedesSupervisor.exe'
 Start-Process -FilePath $supervisor -WorkingDirectory $root | Out-Null
 Log 'Started GUI-mode Mercedes supervisor. Waiting for visible responsive Mercedes Home.'

 # Native check: FindWindow + visibility + SendMessageTimeout; this verifies actual WPF UI,
 # not a PowerShell process (which could run in the background with no usable Home screen).
 Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class MercedesWindowCheck {
 [DllImport("user32.dll", EntryPoint="FindWindowW",CharSet=CharSet.Unicode)]
 public static extern IntPtr FindWindow(string windowClass,string title);
 [DllImport("user32.dll")]public static extern bool IsWindowVisible(IntPtr handle);
 [DllImport("user32.dll",EntryPoint="SendMessageTimeoutW")]
 public static extern IntPtr SendMessageTimeout(IntPtr handle,uint message,IntPtr wParam,IntPtr lParam,uint flags,uint timeout,out IntPtr result);
}
'@ -ErrorAction Stop
 $healthy=$false
 $deadline=(Get-Date).AddSeconds(55)
 do{
  $handle=[MercedesWindowCheck]::FindWindow($null,'Mercedes Diagnostic System')
  if($handle -ne [IntPtr]::Zero -and [MercedesWindowCheck]::IsWindowVisible($handle)){
   $result=[IntPtr]::Zero
   $reply=[MercedesWindowCheck]::SendMessageTimeout($handle,0,[IntPtr]::Zero,[IntPtr]::Zero,2,1000,[ref]$result)
   if($reply -ne [IntPtr]::Zero){$healthy=$true;break}
  }
  Start-Sleep -Seconds 2
 }while((Get-Date) -lt $deadline)
 if(-not $healthy){
  $logDir=Join-Path $root 'logs'
  foreach($n in @('Supervisor.log','Launcher.log','Dock.log')){
   $lf=Join-Path $logDir $n
   if(Test-Path $lf){Log ('--- '+$n+' ---');foreach($line in @(Get-Content $lf -Tail 12)) {Log ('  '+$line)}}
  }
  throw 'Mercedes Home did not show a responsive window within 55 seconds. Check Mercedes-Workstation-Install.log for captured Launcher errors.'
 }
 Log ('Installed; desktop responds; backup '+$backup)
 Write-Output ('SUCCESS: '+$root)
 Write-Output ('BACKUP: '+$backup)
 exit 0
}catch{
 $message=$_.Exception.Message
 Log ('INSTALL ERROR: '+$message)
 # Stop only Mercedes-owned processes before restoring backed-up files.
 try {
  Get-CimInstance Win32_Process -Filter "Name='MercedesSupervisor.exe'" -ErrorAction SilentlyContinue |
    Where-Object {$_.ExecutablePath -eq (Join-Path $root 'MercedesSupervisor.exe')} |
    ForEach-Object {Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -match 'Mercedes-Diagnostic-Workstation\\(Launcher|Dock|Watchdog|UpdateAgent)\.ps1' -and $_.ProcessId -ne $PID } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
 } catch {}
 # Restore file state rather than leave a half-installed installation behind.
 if($backup -and (Test-Path $backup)){
  foreach($name in $files+@('apps.json')){
   $dest=Join-Path $root $name
   if((Test-Path (Join-Path $backup $name))){Copy-Item (Join-Path $backup $name) $dest -Force -ErrorAction SilentlyContinue}
   elseif($name -in $created){Remove-Item $dest -Force -ErrorAction SilentlyContinue}
  }
 }
 # If this replaced an existing Mercedes setup, recover its supervisor after restoring files.
 if($previous.ContainsKey('MercedesSupervisor.exe') -and $previous['MercedesSupervisor.exe']){
  try {
   Start-Process -FilePath (Join-Path $root 'MercedesSupervisor.exe') | Out-Null
  } catch {}
 }
 if($null -ne $oldRun){New-ItemProperty -Path $runKey -Name $runName -Value $oldRun -PropertyType String -Force -ErrorAction SilentlyContinue | Out-Null}
 else{Remove-ItemProperty -Path $runKey -Name $runName -ErrorAction SilentlyContinue}
 Write-Error $message
 exit 1
}
