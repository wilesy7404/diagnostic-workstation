Option Explicit
Dim sh, ps, target
Set sh = CreateObject("WScript.Shell")
ps = sh.ExpandEnvironmentStrings("%WINDIR%") & "\System32\WindowsPowerShell\v1.0\powershell.exe"
target = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Mercedes-Diagnostic-Workstation\Watchdog.ps1"
sh.Run Chr(34) & ps & Chr(34) & " -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & target & Chr(34), 0, False
