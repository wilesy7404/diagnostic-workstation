MERCEDES DIAGNOSTIC WORKSTATION — ONE-CLICK INSTALLER
Version: 1.0.0-beta.2 | Windows 10/11 x64 | PowerShell 5.1 + .NET WPF

RUN: On the MERCEDES Windows installation, double-click Mercedes-Workstation-Setup.exe.
Click Yes. It extracts its own embedded files, validates their PowerShell syntax,
installs for the signed-in Windows user, creates a desktop shortcut, enables login
startup, runs the GUI-mode supervisor and verifies an actual visible, responsive Mercedes Home window.
No manual extraction, zip, compiler or downloaded components required.

INCLUDES
- Mercedes-branded fullscreen WPF Home and star emblem
- Mercedes glass app-switcher dock; animated hide and touch reveal
- Compact attached SYSTEM menu (including Microsoft Edge)
- ADMIN editor for application names, paths, icons, descriptions and visibility
- Empty shortcut templates: XENTRY Diagnosis, DTS Monaco, Vediamo, WIS / ASRA
- GUI-mode supervisor restarts Home and dock without hiding their WPF windows
- Mercedes-only update agent, updater GUI/progress, download checksum check,
  independent installer/rollback worker, plus per-install backups
- Desktop shortcut and HKCU login startup for current Windows installation
- Recovery script in %LOCALAPPDATA%\Mercedes-Diagnostic-Workstation

IMPORTANT BOUNDARIES
- This package DOES NOT include or install Mercedes-Benz XENTRY, DTS Monaco,
  Vediamo, WIS or ASRA binaries, subscriptions, licenses, databases or drivers.
  Configure paths to legally obtained applications via ADMIN after install.
- Mercedes checks ONLY GitHub releases with tags like 'mercedes-v1.0.1-beta.1';
  BMW releases (v1.0.1-beta.5) will never auto-install on Mercedes.
- The installer NEVER writes HKLM Winlogon Shell or replaces Explorer. This is
  intentional: the fullscreen Home is auto-started at login, providing the
  workstation experience with a normal Windows fallback.
- If the BMW launcher is currently running on the same Windows installation,
  installation aborts. Install under the separate Mercedes Windows boot instead.
- The installer is not digitally code-signed. Windows SmartScreen may warn.
  Only run this file if you trust the file's origin.
- This was built in Linux as a true Windows PE .exe; the Windows WPF UI and
  full installation flow MUST still be tested on the target Windows machine.

INSTALLED PATH
%LOCALAPPDATA%\Mercedes-Diagnostic-Workstation

RECOVERY
Use Task Manager > Run new task > explorer.exe to restore the Windows desktop.
Use Task Manager > Run new task > powershell.exe, then run:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$env:LOCALAPPDATA\Mercedes-Diagnostic-Workstation\Recover-Mercedes.ps1"
For an error log, open:
  %TEMP%\Mercedes-Workstation-Install.log

UPDATES
Mercedes-only tags: 'mercedes-v1.0.1-beta.1' (not BMW 'v1.0.1-beta.5').
Assets: workstation.zip, update-manifest.json, workstation.zip.sha256.
Inside workstation.zip: core/{Launcher,Dock,Watchdog,SystemPanel}.ps1,
version.json. Manifest 'version' without tag prefix, SHA256 matching ZIP bytes.
Never distribute Mercedes releases using BMW-only tag names.

V2 STARTUP FIX
- Original installer used -WindowStyle Hidden to spawn WPF Home. The diagnostic preview showed that a normal visible launch works.
- V2 starts PowerShell from a console-free GUI process; WPF windows can be displayed normally.
- Inspector checks that a visible, responsive Mercedes Home window exists, with captured logs.
