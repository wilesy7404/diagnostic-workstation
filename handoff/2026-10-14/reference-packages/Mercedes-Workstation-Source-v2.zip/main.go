// Mercedes Diagnostic Workstation — self-contained Windows x64 installer.
// The EXE embeds all installer assets; no internet download required.
package main

import (
    "bytes"
    "embed"
    "os"
    "os/exec"
    "path/filepath"
    "runtime"
    "strings"
    "syscall"
    "unsafe"
)

//go:embed payload/*
var content embed.FS

const (
    mbOK = 0x00000000
    mbYesNo = 0x00000004
    mbIconQuestion = 0x00000020
    mbIconInfo = 0x00000040
    mbIconError = 0x00000010
    idYes = 6
    createNoWindow = 0x08000000
)

func dialog(caption, message string, flags uintptr) int {
    user32 := syscall.NewLazyDLL("user32.dll")
    fn := user32.NewProc("MessageBoxW")
    ptrText, _ := syscall.UTF16PtrFromString(message)
    ptrTitle, _ := syscall.UTF16PtrFromString(caption)
    r, _, _ := fn.Call(0, uintptr(unsafe.Pointer(ptrText)), uintptr(unsafe.Pointer(ptrTitle)), flags)
    runtime.KeepAlive(ptrText)
    runtime.KeepAlive(ptrTitle)
    return int(r)
}

func fail(problem string) {
    dialog("Mercedes Workstation - Installation stopped", problem, mbOK|mbIconError)
    os.Exit(1)
}

func main() {
    if strings.ToLower(os.Getenv("PROCESSOR_ARCHITECTURE")) == "arm64" {
        fail("This installer is for 64-bit Intel/AMD Windows. Windows ARM is not supported by this build.")
    }
    if dialog("Mercedes Diagnostic Workstation", "Install the Mercedes Diagnostic Workstation for this Windows user?\n\nIncludes: Mercedes Home, ADMIN app editor, glass dock, SYSTEM popup, console-free supervisor and Mercedes-only update checks.\n\nNo Mercedes XENTRY/DTS/Vediamo software or licenses are included.\n\nThe installer may take up to a minute. It will start Mercedes Home and enable login startup. It will NOT replace the Windows shell or change the BMW installation.", mbYesNo|mbIconQuestion) != idYes {
        return
    }

    local := os.Getenv("LOCALAPPDATA")
    if local == "" {
        fail("Windows LOCALAPPDATA is not set. Sign in as your normal Windows user and try again.")
    }
    stage, err := os.MkdirTemp("", "mercedes-workstation-install-")
    if err != nil {
        fail("Unable to create temporary installation folder: " + err.Error())
    }
    defer os.RemoveAll(stage)

    items, err := content.ReadDir("payload")
    if err != nil { fail("Embedded installation files are missing: " + err.Error()) }
    for _, item := range items {
        if item.IsDir() { continue }
        name := item.Name()
        if name == "" || strings.ContainsAny(name, `/\\`) { fail("Unexpected embedded file name") }
        data, err := content.ReadFile("payload/" + name)
        if err != nil { fail("Could not read embedded file: " + name) }
        if err := os.WriteFile(filepath.Join(stage, name), data, 0600); err != nil {
            fail("Unable to write temporary file: " + err.Error())
        }
    }

    ps := filepath.Join(os.Getenv("WINDIR"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    cmd := exec.Command(ps, "-NoProfile", "-NonInteractive", "-STA", "-ExecutionPolicy", "Bypass", "-File", filepath.Join(stage, "Install-Mercedes.ps1"), "-PayloadDirectory", stage)
    cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow:true, CreationFlags:createNoWindow}
    var output bytes.Buffer
    cmd.Stdout = &output
    cmd.Stderr = &output
    err = cmd.Run()
    if err != nil {
        all := output.String()
        if len(all) > 1500 { all=all[len(all)-1500:] }
        msg := "Installation was not completed. The installer attempted to restore earlier files.\n\n" + strings.TrimSpace(all) + "\n\nLog: " + filepath.Join(os.TempDir(), "Mercedes-Workstation-Install.log")
        fail(msg)
    }
    root := filepath.Join(local, "Mercedes-Diagnostic-Workstation")
    if _, err := os.Stat(filepath.Join(root,"Launcher.ps1")); err != nil { fail("Installer exited successfully, but Mercedes Home files weren't found. See installation log.") }
    dialog("Mercedes Diagnostic Workstation - Installed", "Installation complete.\n\nMercedes Home opened successfully, with its dock and supervisor enabled.\n\nYou can set your own paths to XENTRY, DTS Monaco, Vediamo and WIS in ADMIN. Nothing was copied from your BMW configuration.\n\nThe workstation will automatically launch when you sign into this Windows installation.\n\nFor safety, Explorer remains the Windows shell until you choose to change it separately.\n\nInstalled at:\n" + root, mbOK|mbIconInfo)
}
