MERCEDES DIAGNOSTIC WORKSTATION - SAFETY CONTROLS v1.0

This update is for the current Mercedes profile of the Universal Diagnostic Workstation.
It does NOT activate/replace the Windows Explorer shell. Do not turn on shell mode until
all controls have been tested on this computer.

INSTALL (in Windows PowerShell, as the Mercedes Windows user):
  $zip="$env:USERPROFILE\Downloads\Mercedes-Controls-PreShell-v1.zip"
  $dir="$env:TEMP\Mercedes-Controls-PreShell-v1"
  Expand-Archive -LiteralPath $zip -DestinationPath $dir -Force
  & "$dir\Install-Mercedes-Controls.ps1"

The installer asks you to set a unique 6-12 digit PIN for Desktop Mode.
It backs up existing SystemPanel.ps1 and Dock.ps1 into a dated ControlBackup-* folder.
It preserves Launcher.ps1, logo, dock positioning, updater and all application tiles.
The installer verifies PowerShell syntax and XAML well-formedness before writing.

RESTART (after PASS, in Windows PowerShell):
  & "$env:LOCALAPPDATA\DiagnosticWorkstation\Restart-Mercedes-Controls.ps1"

SYSTEM menu (Home + Dock):
  Wi-Fi & Internet: find available WLANs, connect saved networks or WPA2-Personal with password
  Battery: opens battery and power-source status; battery indicator also appears on dock
  Windows Settings: opens system settings (Wi-Fi panel includes dedicated Wi-Fi Settings)
  Windows Desktop (PIN): start Explorer and temporarily minimize workstation and dock
  Emergency Recovery: restore Explorer per-user shell setting without a PIN

When in Desktop Mode, use the desktop shortcut "Return to Mercedes Workstation".
If the shortcut is missing, run from PowerShell:
  & "$env:LOCALAPPDATA\DiagnosticWorkstation\WorkstationControls.ps1" -Mode Return

EMERGENCY RECOVERY if shell fails later:
  Ctrl+Shift+Esc -> Task Manager -> Run new task ->
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\Mercedes\AppData\Local\DiagnosticWorkstation\Restore-ExplorerShell.ps1"

Wi-Fi direct setup supports only WPA2 Personal with AES. Windows Settings may be necessary
for WPA3, Enterprise/802.1X, captive portals, or other network types. A temporary WLAN
profile containing the entered WPA2 passphrase is deleted after adding it to Windows; the
Windows WLAN profile may store the credential for future automatic connection.

The PIN is a local convenience gate, not a Windows authentication mechanism or a
security boundary. Anyone who can run Task Manager, PowerShell, recovery or modify files
under this Windows user account can bypass it. For real protection, use a Windows sign-in
password and suitable Windows account/organization policies. Emergency recovery
intentionally does not require the PIN.

If the installer fails, it is supposed to leave the shell unchanged and the previous
Home/Dock files intact. If partial file saves fail, the installer attempts rollback.

DO NOT ENABLE FULL CUSTOM SHELL UNTIL: Wi-Fi test works, battery appears, Windows Settings
opens, wrong desktop PIN is refused, correct PIN opens the Explorer desktop, the Return
shortcut works, and emergency recovery instructions are accessible.
