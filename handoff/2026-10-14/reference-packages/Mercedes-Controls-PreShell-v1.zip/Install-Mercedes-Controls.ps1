# Mercedes Universal Workstation controls update v1.0.
# Does NOT enable or replace the Windows shell. Windows PowerShell 5.1.
& {
    $ErrorActionPreference='Stop'
    $root=Join-Path $env:LOCALAPPDATA 'DiagnosticWorkstation'
    $launcherFile=Join-Path $root 'Launcher.ps1'
    $dockFile=Join-Path $root 'Dock.ps1'
    $panelFile=Join-Path $root 'SystemPanel.ps1'
    $profileFile=Join-Path $root 'profile.json'
    $newFiles=@('WorkstationControls.ps1','Restore-ExplorerShell.ps1','Restart-Mercedes-Controls.ps1')
    foreach($file in @($launcherFile,$dockFile,$panelFile,$profileFile)) {
        if (-not(Test-Path -LiteralPath $file)) { throw "Required workstation file not found: $file" }
    }
    $profile=Get-Content $profileFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if (([string]$profile.displayName) -notmatch 'Mercedes') {
        throw "This update targets the Mercedes user profile, not $($profile.displayName). Nothing changed."
    }
    $launcherCode=[IO.File]::ReadAllText($launcherFile)
    $dockCode=[IO.File]::ReadAllText($dockFile)
    $panelCode=[IO.File]::ReadAllText($panelFile)
    $marker='MERCEDES-SAFE-CONTROLS-v1'
    if ($dockCode.Contains($marker) -or $panelCode.Contains($marker)) {
        throw 'This controls update is already installed. Nothing changed.'
    }

    function Replace-ExactlyOnce([string]$inputText,[string]$findText,[string]$replacement,[string]$description) {
        $index=$inputText.IndexOf($findText,[StringComparison]::Ordinal)
        if ($index -lt 0) {throw "Unsupported workstation version: $description anchor not found. Nothing changed."}
        if ($inputText.IndexOf($findText,$index+$findText.Length,[StringComparison]::Ordinal) -ge 0) {
            throw "Unexpected duplicate $description anchors. Nothing changed."
        }
        return $inputText.Replace($findText,$replacement)
    }

    # Home SYSTEM menu: keep existing appearance/alignment, add working quick actions.
    $homeNewButtons=@'
<Button x:Name="WcWifi" Content="Wi-Fi &amp; Internet"/>
<Button x:Name="WcBattery" Content="Battery Status"/>
<Button x:Name="WcDesktop" Content="Windows Desktop (PIN)"/>
<Button x:Name="WcRecovery" Content="Emergency Recovery"/>
'@
    $panelCode=Replace-ExactlyOnce $panelCode '<Button x:Name="Internet"' ($homeNewButtons + '        <Button x:Name="Internet"') 'Home SYSTEM buttons'
    $panelActions=@'
        WcWifi     = { Invoke-WorkstationControl 'Wifi' }
        WcBattery  = { Invoke-WorkstationControl 'Battery' }
        WcDesktop  = { Invoke-WorkstationControl 'Desktop' }
        WcRecovery = { Invoke-WorkstationControl 'Recovery' }
'@
    $panelCode=Replace-ExactlyOnce $panelCode '    $actions = @{' ("    `$actions = @{`r`n" + $panelActions) 'Home SYSTEM actions'
    $panelFunction=@'
# MERCEDES-SAFE-CONTROLS-v1
function Invoke-WorkstationControl([string]$mode) {
    $file = Join-Path $env:LOCALAPPDATA 'DiagnosticWorkstation\WorkstationControls.ps1'
    if(-not(Test-Path -LiteralPath $file)){throw "Workstation controls missing: $file"}
    $psExe = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Start-Process -FilePath $psExe -WindowStyle Hidden -ArgumentList @(
       '-NoProfile','-STA','-ExecutionPolicy','Bypass',"-File `"$file`"",'-Mode',$mode
    )
}
'@
    $panelCode=$panelFunction + "`r`n" + $panelCode
    # Fix prior SystemPanel function-scope MyInvocation null-path issue if the old source is present.
    $oldProfile="(Join-Path (Split-Path -Parent `$MyInvocation.MyCommand.Path) 'profile.json')"
    if($panelCode.Contains($oldProfile)) {
        $panelCode=$panelCode.Replace($oldProfile,"(Join-Path `$root 'profile.json')")
    }

    # Dock: status indicator and matching quick actions. Leave Move-Dock, animation and artwork untouched.
    $dockBattery=@'
<Button x:Name="WcBatteryButton" Style="{StaticResource DockButton}" ToolTip="Battery status">
     <StackPanel Orientation="Vertical" HorizontalAlignment="Center" VerticalAlignment="Center">
      <TextBlock Text="&#xE850;" FontFamily="Segoe MDL2 Assets" FontSize="17" Foreground="#E9F4FF" TextAlignment="Center"/>
      <TextBlock x:Name="WcBatteryPercent" Text="--" FontFamily="Segoe UI" FontSize="9" Foreground="#E9F4FF" TextAlignment="Center"/>
     </StackPanel>
    </Button>
    <Button x:Name="System"
'@
    $dockCode=Replace-ExactlyOnce $dockCode '<Button x:Name="System"' $dockBattery 'dock battery button'
    $dockHelper=@'
# MERCEDES-SAFE-CONTROLS-v1
function Invoke-MercedesDockControl([string]$mode) {
    $file=Join-Path $env:LOCALAPPDATA 'DiagnosticWorkstation\WorkstationControls.ps1'
    if(-not(Test-Path -LiteralPath $file)){throw "Workstation controls missing: $file"}
    $psExe=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Start-Process -FilePath $psExe -WindowStyle Hidden -ArgumentList @(
        '-NoProfile','-STA','-ExecutionPolicy','Bypass',"-File `"$file`"",'-Mode',$mode
    )
}
$window.FindName('WcBatteryButton').Add_Click({Invoke-MercedesDockControl 'Battery'})
'@
    $dockCode=Replace-ExactlyOnce $dockCode '$menu=New-Object System.Windows.Controls.ContextMenu' ($dockHelper+"`r`n"+'$menu=New-Object System.Windows.Controls.ContextMenu') 'dock menu initialization'
    $dockExtraChoices=@'
$choices+=@(
 @{Text='Wi-Fi & Internet';Cmd='wcwifi'},
 @{Text='Battery Status';Cmd='wcbattery'},
 @{Text='Windows Settings';Cmd='wcsettings'},
 @{Text='Windows Desktop (PIN)';Cmd='wcdesktop'},
 @{Text='Emergency Recovery';Cmd='wcrecovery'}
)
'@
    $dockCode=Replace-ExactlyOnce $dockCode 'foreach($c in $choices){' ($dockExtraChoices+"`r`n"+'foreach($c in $choices){') 'dock menu choices'
    $dockCases=@'
    wcwifi {Invoke-MercedesDockControl 'Wifi'}
    wcbattery {Invoke-MercedesDockControl 'Battery'}
    wcsettings {Invoke-MercedesDockControl 'Settings'}
    wcdesktop {Invoke-MercedesDockControl 'Desktop'}
    wcrecovery {Invoke-MercedesDockControl 'Recovery'}
'@
    $dockCode=Replace-ExactlyOnce $dockCode "   taskmgr {Start-Process 'taskmgr.exe'}" ("   taskmgr {Start-Process 'taskmgr.exe'}`r`n"+$dockCases) 'dock menu actions'
    $batteryStatus=@'
# Battery status is updated independently without altering fullscreen hide/reveal logic.
$script:wcBatteryPercent=$window.FindName('WcBatteryPercent')
$wcBatteryTimer=New-Object System.Windows.Threading.DispatcherTimer
$wcBatteryTimer.Interval=[TimeSpan]::FromSeconds(20)
$wcBatteryTimer.Add_Tick({
    try {
        $info=[System.Windows.Forms.SystemInformation]::PowerStatus
        $pct=$info.BatteryLifePercent
        if ($pct -ge 0 -and $pct -le 1 -and
            ($info.BatteryChargeStatus -band [System.Windows.Forms.BatteryChargeStatus]::NoSystemBattery) -eq 0) {
            $script:wcBatteryPercent.Text=('{0}%' -f [Math]::Round($pct*100))
        } else { $script:wcBatteryPercent.Text='AC' }
    } catch { $script:wcBatteryPercent.Text='--' }
})
$window.Add_Loaded({
$wcBatteryTimer.Start()
    try {
        $info=[System.Windows.Forms.SystemInformation]::PowerStatus
        $pct=$info.BatteryLifePercent
        $script:wcBatteryPercent.Text=if($pct -ge 0 -and $pct -le 1){('{0}%' -f [Math]::Round($pct*100))}else{'AC'}
    } catch { $script:wcBatteryPercent.Text='--' }
})
'@
    $dockCode=Replace-ExactlyOnce $dockCode '[void]$window.ShowDialog()' ($batteryStatus+"`r`n"+'[void]$window.ShowDialog()') 'dock launch'

    # Verify all source PowerShell syntax and XAML syntax before touching installed files.
    function Assert-PS([string]$text,[string]$description) {
        $tok=$null;$errors=$null
        [void][System.Management.Automation.Language.Parser]::ParseInput($text,[ref]$tok,[ref]$errors)
        if (@($errors).Count -gt 0) {
            $errors | Select-Object -First 4 -ExpandProperty Message | ForEach-Object {Write-Host $_ -ForegroundColor Red}
            throw "$description PowerShell validation failed. Nothing changed."
        }
    }
    Assert-PS $panelCode 'Home menu'
    Assert-PS $dockCode 'Dock'
    foreach($filename in $newFiles) {
        $source=Join-Path $PSScriptRoot $filename
        if(-not(Test-Path -LiteralPath $source)){throw "Update package incomplete: $filename"}
        Assert-PS ([IO.File]::ReadAllText($source)) $filename
    }
    foreach($check in @(
       @{source=$panelCode;name='Home';pattern='(?s)\[xml\]\$xaml\s*=\s*@''\s*\r?\n(.*?)\r?\n''@'},
       @{source=$dockCode;name='Dock';pattern='(?s)\$xml\s*=\s*@''\s*\r?\n(.*?)\r?\n''@'}
    )) {
        $match=[regex]::Match($check.source,$check.pattern)
        if(-not $match.Success){throw "Cannot extract $($check.name) XAML for validation. Nothing changed."}
        try{[void][xml]$match.Groups[1].Value}catch{throw "$($check.name) XAML invalid: $_"}
    }

    # Require a user-defined six-or-more-digit PIN, not a default PIN.
    $pinFile=Join-Path $root 'controls-pin.json'
    $newPin=$null
    if(-not(Test-Path $pinFile)) {
        Write-Host "`nCreate a desktop access passcode (6-12 digits)." -ForegroundColor Cyan
        function Read-Secret([string]$caption) {
            $secure=Read-Host -Prompt $caption -AsSecureString
            $ptr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
            try {return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)}
            finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr);$secure.Dispose()}
        }
        $one=Read-Secret 'New PIN'
        $two=Read-Secret 'Confirm PIN'
        if($one -notmatch '^\d{6,12}$' -or $one -cne $two) {
            throw 'PIN must be 6-12 digits and both entries must match. Nothing changed.'
        }
        $salt=New-Object byte[] 16
        $rng=[System.Security.Cryptography.RandomNumberGenerator]::Create()
        try{$rng.GetBytes($salt)}finally{$rng.Dispose()}
        $kdf=New-Object System.Security.Cryptography.Rfc2898DeriveBytes($one,$salt,150000)
        try{$hash=$kdf.GetBytes(32)}finally{$kdf.Dispose()}
        $newPin=([pscustomobject]@{
           version=1;iterations=150000;salt=[Convert]::ToBase64String($salt);hash=[Convert]::ToBase64String($hash)
        } | ConvertTo-Json -Compress)
        $one=$null;$two=$null
    }

    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    $backupDir=Join-Path $root ('ControlBackup-'+$stamp)
    New-Item -ItemType Directory -Path $backupDir -ErrorAction Stop | Out-Null
    foreach($file in @($launcherFile,$dockFile,$panelFile)+@($newFiles | ForEach-Object{Join-Path $root $_})) {
        if(Test-Path $file){Copy-Item -LiteralPath $file -Destination (Join-Path $backupDir ([IO.Path]::GetFileName($file))) -ErrorAction Stop}
    }
    if(Test-Path $pinFile){Copy-Item $pinFile (Join-Path $backupDir 'controls-pin.json') -ErrorAction Stop}

    $encoding=New-Object System.Text.UTF8Encoding($false)
    $didSave=$false
    try {
        # Install the control script(s) before patching any live menu references.
        foreach($filename in $newFiles){Copy-Item (Join-Path $PSScriptRoot $filename) (Join-Path $root $filename) -Force -ErrorAction Stop}
        if($newPin){[IO.File]::WriteAllText($pinFile,$newPin,$encoding)}
        [IO.File]::WriteAllText($panelFile,$panelCode,$encoding)
        [IO.File]::WriteAllText($dockFile,$dockCode,$encoding)
        $didSave=$true
    } catch {
        # Restore both original menus, and remove newly created helper files.
        foreach($file in @($launcherFile,$dockFile,$panelFile)){
            $saved=Join-Path $backupDir ([IO.Path]::GetFileName($file))
            if(Test-Path $saved){Copy-Item $saved $file -Force}
        }
        foreach($filename in $newFiles){
            $saved=Join-Path $backupDir $filename
            $target=Join-Path $root $filename
            if(Test-Path $saved){Copy-Item $saved $target -Force}
            elseif(Test-Path $target){Remove-Item $target -Force}
        }
        if($newPin -and (Test-Path $pinFile)){Remove-Item $pinFile -Force}
        throw
    }
    if(-not $didSave){throw 'Installer did not complete.'}

    # Accessible recovery independent of the SYSTEM popup and custom shell.
    $desktopPath=[Environment]::GetFolderPath('DesktopDirectory')
    try {
        if(Test-Path $desktopPath){
            $short=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktopPath 'Return to Mercedes Workstation.lnk'))
            $short.TargetPath=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
            $controls=Join-Path $root 'WorkstationControls.ps1'
            $short.Arguments="-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$controls`" -Mode Return"
            $short.WorkingDirectory=$root
            $short.Description='Return to Mercedes Diagnostic Workstation'
            $short.Save()
        }
    } catch {
        Write-Warning 'Desktop return shortcut could not be created. Return mode still available via the script.'
    }

    Write-Host "`nPASS: Mercedes controls installed (shell NOT changed)." -ForegroundColor Green
    Write-Host "Backup: $backupDir"
    Write-Host 'Next: & "$env:LOCALAPPDATA\DiagnosticWorkstation\Restart-Mercedes-Controls.ps1"'
    Write-Host 'Test Wi-Fi, Battery, Settings, Desktop PIN and return, Recovery before enabling shell mode.'
}
